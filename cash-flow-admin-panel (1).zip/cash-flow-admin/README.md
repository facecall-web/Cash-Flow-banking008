# Cash Flow Admin Panel — starter

Responsive burgundy/white admin dashboard for Firebase project `cash-flow-banking-c708d`.

## What is included

- Responsive React + TypeScript + Vite UI, with left sidebar and USD display.
- Firebase Email/Password sign-in.
- Customer list reads from Firestore only after sign-in; rules are locked down by default.
- Cashflow chart and sample transaction rows clearly labelled as sample data.
- Starter Firebase Cloud Functions that enforce the Firebase custom claim `admin: true`.
- Firestore rules default-deny.
- Owner-only local script to assign the custom admin claim.

## Important safety note

This is a starter/prototype, not a live banking system. It does not move real money, implement payment rails, or make the sample transactions real. Do not enable customer balance mutations until a ledger model, atomic transaction processing, idempotency, reconciliation, and proper review have been implemented. Do not store passwords, PINs, card data, or secret keys in Firestore.

## 1. Prerequisites

Install Node.js 20+ and npm on a computer. Install the Firebase CLI if deploying functions/rules:
`npm install -g firebase-tools`

## 2. Run the UI locally

In this folder:
`npm install`
`npm run dev`

Open the local URL printed by Vite. Sign in with an existing Firebase Authentication user. If you don't have one, create a test account using Firebase Console → Authentication → Users → Add user.

The Firebase web configuration in `src/firebase.ts` is public client configuration; security comes from Auth, rules, and backend checks. Never add a service-account key to `src/`.

## 3. Configure Firestore

`firestore.rules` denies all direct reads/writes by default. This is intentional. Deploy it only if you want the initial locked-down state:
`firebase login`
`firebase use cash-flow-banking-c708d`
`firebase deploy --only firestore:rules`

With these rules, the customer list will show restricted/not configured until you deploy role-aware rules. Do not open Firestore to public access to make the UI work.

## 4. Assign the first owner administrator

1. Create the owner's sign-in user under Firebase Console → Authentication → Users.
2. Use a trusted computer / Cloud Shell. Enable Application Default Credentials for the project, or securely set `GOOGLE_APPLICATION_CREDENTIALS` to a service-account JSON outside this project directory.
3. Install the Admin SDK for the one-time script, e.g. from the project root: `npm install firebase-admin`
4. Run: `node scripts/set-admin.mjs admin@example.com`
5. Sign out and sign in again so the Firebase ID token contains the updated `admin` custom claim.

The script uses privileged Admin SDK credentials. Never upload that credential to the web app, a public repository, or this chat.

## 5. Deploy Cloud Functions

From the project root:
`cd functions && npm install && cd ..`
`firebase deploy --only functions`

Functions reject calls unless `request.auth.token.admin === true`. Review and test them before production use.

## 6. Next implementation steps

1. Add role-aware Firestore rules for customer profiles, transaction records, deposit requests, and audit logs.
2. Replace sample transactions and chart data with backend-provided aggregate data.
3. Implement append-only ledger entries and atomic/idempotent transfer/deposit workflows.
4. Add approval/deposit workflows and transaction-limit enforcement in trusted functions.
5. Add tests, App Check, rate limiting, logging, monitoring, and backup/recovery plans.

For real-money financial services, use licensed payment/banking partners and obtain relevant compliance review before launch.
