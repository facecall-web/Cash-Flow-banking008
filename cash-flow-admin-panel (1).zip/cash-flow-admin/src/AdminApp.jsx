import React, { useMemo, useState } from "react";
import {
  Activity, ArrowDownLeft, ArrowUpRight, Bell, BriefcaseBusiness, Check,
  ChevronDown, CircleHelp, CreditCard, Download, Eye, FileClock, Filter,
  LayoutDashboard, LogOut, Menu, MoreHorizontal, Search, Settings, ShieldCheck,
  SlidersHorizontal, UserRound, Users, Wallet, X, Ban, Snowflake, Plus,
  ArrowLeftRight, Clock3, CircleDollarSign, ChartNoAxesCombined
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis
} from "recharts";

const money = (value) => new Intl.NumberFormat("en-NG", {
  style: "currency", currency: "NGN", maximumFractionDigits: 0
}).format(value);

const chartData = [
  { day: "Mon", inflow: 240000, outflow: 160000 },
  { day: "Tue", inflow: 360000, outflow: 210000 },
  { day: "Wed", inflow: 290000, outflow: 180000 },
  { day: "Thu", inflow: 460000, outflow: 310000 },
  { day: "Fri", inflow: 390000, outflow: 230000 },
  { day: "Sat", inflow: 520000, outflow: 280000 },
  { day: "Sun", inflow: 440000, outflow: 250000 }
];

const initialUsers = [
  { id: "CF-100284", name: "Amara Okafor", email: "amara.okafor@example.com", date: "Oct 10, 2026", balance: 285000, status: "Active", type: "Personal" },
  { id: "CF-100285", name: "Daniel Adeyemi", email: "daniel.adeyemi@example.com", date: "Oct 09, 2026", balance: 124500, status: "Pending", type: "Personal" },
  { id: "CF-100286", name: "Zara Bello", email: "zara.bello@example.com", date: "Oct 08, 2026", balance: 840000, status: "Frozen", type: "Business" },
  { id: "CF-100287", name: "Chidi Nwosu", email: "chidi.nwosu@example.com", date: "Oct 07, 2026", balance: 56200, status: "Active", type: "Personal" },
  { id: "CF-100288", name: "Mariam Yusuf", email: "mariam.yusuf@example.com", date: "Oct 06, 2026", balance: 412000, status: "Pending", type: "Business" }
];

const initialTransactions = [
  { id: "TX-80431", name: "Amara Okafor", kind: "Transfer", date: "Oct 12, 2026 · 10:42 AM", amount: -45000, status: "Completed" },
  { id: "TX-80430", name: "Daniel Adeyemi", kind: "Deposit request", date: "Oct 12, 2026 · 10:18 AM", amount: 80000, status: "Pending" },
  { id: "TX-80429", name: "Chidi Nwosu", kind: "Transfer", date: "Oct 12, 2026 · 09:56 AM", amount: -12000, status: "Completed" },
  { id: "TX-80428", name: "Mariam Yusuf", kind: "Deposit request", date: "Oct 11, 2026 · 04:22 PM", amount: 150000, status: "Pending" },
  { id: "TX-80427", name: "Zara Bello", kind: "Card payment", date: "Oct 11, 2026 · 02:07 PM", amount: -8500, status: "Declined" }
];

const navGroups = [
  { title: "OVERVIEW", items: [{ id: "Overview", icon: LayoutDashboard }, { id: "Analytics", icon: ChartNoAxesCombined }] },
  { title: "MANAGEMENT", items: [{ id: "Customers", icon: Users }, { id: "Transactions", icon: ArrowLeftRight }, { id: "Deposits", icon: Wallet }, { id: "Cards & Services", icon: CreditCard }] },
  { title: "SYSTEM", items: [{ id: "Activity Log", icon: FileClock }, { id: "Settings", icon: Settings }] }
];

function Badge({ children }) {
  const key = String(children).toLowerCase();
  const cls = key.includes("active") || key.includes("completed") || key.includes("approved") ? "green"
    : key.includes("pending") ? "amber"
    : key.includes("frozen") || key.includes("declined") || key.includes("banned") ? "red"
    : "gray";
  return <span className={`badge ${cls}`}><span />{children}</span>;
}

function StatCard({ title, value, change, icon: Icon, tone, note }) {
  return <div className="stat-card">
    <div className="stat-top"><span>{title}</span><span className={`stat-icon ${tone}`}><Icon size={19} /></span></div>
    <div className="stat-value">{value}</div>
    <div className="stat-bottom"><span className="change"><ArrowUpRight size={14} /> {change}</span><span>{note}</span></div>
  </div>;
}

export default function AdminApp() {
  const [active, setActive] = useState("Overview");
  const [mobileNav, setMobileNav] = useState(false);
  const [users, setUsers] = useState(initialUsers);
  const [transactions, setTransactions] = useState(initialTransactions);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [selectedUser, setSelectedUser] = useState(null);
  const [toast, setToast] = useState("");
  const [modal, setModal] = useState("");
  const [creditAmount, setCreditAmount] = useState("");
  const [creditReason, setCreditReason] = useState("");
  const [limitAmount, setLimitAmount] = useState("200000");
  const [noticeOpen, setNoticeOpen] = useState(false);

  const notify = (message) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 3000);
  };

  const filteredUsers = useMemo(() => users.filter((u) => {
    const matches = `${u.name} ${u.email} ${u.id}`.toLowerCase().includes(query.toLowerCase());
    return matches && (filter === "All" || u.status === filter);
  }), [users, query, filter]);

  const updateStatus = (id, status) => {
    setUsers((old) => old.map((u) => u.id === id ? { ...u, status } : u));
    setSelectedUser((old) => old?.id === id ? { ...old, status } : old);
    notify(`Demo only: account status set to ${status}.`);
  };

  const approveDeposit = (id) => {
    setTransactions((old) => old.map((t) => t.id === id ? { ...t, status: "Approved" } : t));
    notify("Demo only: deposit request approved in this preview.");
  };

  const doCredit = (e) => {
    e.preventDefault();
    if (!selectedUser || Number(creditAmount) <= 0 || !creditReason.trim()) {
      notify("Enter a valid amount and reason.");
      return;
    }
    setUsers((old) => old.map((u) => u.id === selectedUser.id ? { ...u, balance: u.balance + Number(creditAmount) } : u));
    setSelectedUser((old) => old ? { ...old, balance: old.balance + Number(creditAmount) } : old);
    setModal("");
    setCreditAmount("");
    setCreditReason("");
    notify("Demo only: balance preview updated. No real funds moved.");
  };

  const title = active === "Overview" ? "Dashboard Overview" : active;
  const pending = transactions.filter((t) => t.status === "Pending").length;
  const activeCount = users.filter((u) => u.status === "Active").length;
  const content = () => {
    if (active === "Customers") return <section className="panel table-panel">
      <div className="panel-head table-head"><div><h2>All customers</h2><p>Review customer accounts and account status.</p></div><button className="button secondary" onClick={() => notify("Connect Firebase to export real records.")}><Download size={16}/> Export</button></div>
      <div className="table-tools"><div className="searchbox"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search name, email or account number"/></div><select value={filter} onChange={e => setFilter(e.target.value)}><option>All</option><option>Active</option><option>Pending</option><option>Frozen</option><option>Banned</option></select><button className="button secondary" onClick={() => {setQuery("");setFilter("All");}}><Filter size={16}/> Clear</button></div>
      <div className="table-wrap"><table><thead><tr><th>Customer</th><th>Account number</th><th>Account type</th><th>Balance (preview)</th><th>Status</th><th></th></tr></thead><tbody>
        {filteredUsers.map(u => <tr key={u.id}><td><div className="person-cell"><span className="avatar">{u.name.split(" ").map(s=>s[0]).join("")}</span><div><strong>{u.name}</strong><small>{u.email}</small></div></div></td><td className="mono">{u.id}</td><td>{u.type}</td><td className="amount">{money(u.balance)}</td><td><Badge>{u.status}</Badge></td><td><button className="icon-button" aria-label="View customer" onClick={() => setSelectedUser(u)}><MoreHorizontal size={19}/></button></td></tr>)}
        {filteredUsers.length === 0 && <tr><td colSpan="6" className="empty">No customers match your search.</td></tr>}
      </tbody></table></div>
      <div className="table-foot">Showing {filteredUsers.length} demo customers <span>Live Firebase data is not connected yet.</span></div>
    </section>;

    if (active === "Transactions" || active === "Deposits") {
      const rows = active === "Deposits" ? transactions.filter(t => t.kind === "Deposit request") : transactions;
      return <section className="panel table-panel"><div className="panel-head"><div><h2>{active === "Deposits" ? "Deposit requests" : "Recent transactions"}</h2><p>Review activity. This preview uses sample data only.</p></div><button className="button secondary" onClick={() => notify("Connect Firebase to export real records.")}><Download size={16}/> Export</button></div>
        <div className="table-wrap"><table><thead><tr><th>Reference</th><th>Customer</th><th>Type</th><th>Date</th><th>Amount</th><th>Status</th>{active === "Deposits" && <th>Action</th>}</tr></thead><tbody>
          {rows.map(t=><tr key={t.id}><td className="mono">{t.id}</td><td>{t.name}</td><td>{t.kind}</td><td>{t.date}</td><td className={`amount ${t.amount < 0 ? "negative" : "positive"}`}>{t.amount < 0 ? "−" : "+"}{money(Math.abs(t.amount))}</td><td><Badge>{t.status}</Badge></td>{active === "Deposits" && <td>{t.status === "Pending" ? <button className="button small" onClick={() => approveDeposit(t.id)}><Check size={14}/> Approve demo</button> : "—"}</td>}</tr>)}
        </tbody></table></div></section>;
    }

    if (active === "Analytics") return <section className="panel chart-panel"><div className="panel-head"><div><h2>Cashflow analytics</h2><p>Sample inflow and outflow trend · last 7 days</p></div><span className="demo-tag">PREVIEW DATA</span></div><div className="large-chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData}><defs><linearGradient id="inflow" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8b1739" stopOpacity={0.22}/><stop offset="95%" stopColor="#8b1739" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f4"/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill:"#8b93a3",fontSize:12}}/><YAxis axisLine={false} tickLine={false} tick={{fill:"#8b93a3",fontSize:12}} tickFormatter={v=>`${v/1000}k`}/><Tooltip formatter={(v)=>money(v)}/><Area type="monotone" dataKey="inflow" name="Inflow" stroke="#8b1739" fill="url(#inflow)" strokeWidth={2.5}/><Area type="monotone" dataKey="outflow" name="Outflow" stroke="#e5a04b" fill="#e5a04b" fillOpacity={0.08} strokeWidth={2.5}/></AreaChart></ResponsiveContainer></div></section>;

    if (active === "Cards & Services" || active === "Activity Log" || active === "Settings") return <section className="panel placeholder-panel"><div className="placeholder-icon"><Settings size={28}/></div><h2>{active}</h2><p>This section is planned for the next build step. We’ll connect it to Firebase after admin authentication and database permissions are configured.</p><button className="button" onClick={() => notify(`${active} is on the build roadmap.`)}>Got it</button></section>;

    return <>
      <div className="stat-grid">
        <StatCard title="Total customers" value={users.length.toLocaleString()} change="+12.8%" note="vs last month" icon={Users} tone="wine"/>
        <StatCard title="Active accounts" value={activeCount.toLocaleString()} change="+4.6%" note="vs last month" icon={ShieldCheck} tone="green"/>
        <StatCard title="Pending deposits" value={pending.toLocaleString()} change="Needs review" note="sample requests" icon={Clock3} tone="amber"/>
        <StatCard title="Total balance preview" value={money(users.reduce((s,u)=>s+u.balance,0))} change="Demo data" note="not real funds" icon={CircleDollarSign} tone="blue"/>
      </div>
      <div className="dashboard-grid">
        <section className="panel chart-panel"><div className="panel-head"><div><h2>Cashflow overview</h2><p>Inflow and outflow · sample weekly data</p></div><button className="select-button" onClick={() => setActive("Analytics")}>Last 7 days <ChevronDown size={15}/></button></div><div className="chart-legend"><span><i className="dot burgundy"/> Inflow</span><span><i className="dot gold"/> Outflow</span><span className="demo-tag">PREVIEW DATA</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData}><defs><linearGradient id="cashflow" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8b1739" stopOpacity={0.20}/><stop offset="95%" stopColor="#8b1739" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f4"/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill:"#8b93a3",fontSize:12}}/><YAxis axisLine={false} tickLine={false} tick={{fill:"#8b93a3",fontSize:11}} tickFormatter={v=>`${v/1000}k`}/><Tooltip formatter={(v)=>money(v)}/><Area type="monotone" dataKey="inflow" name="Inflow" stroke="#8b1739" fill="url(#cashflow)" strokeWidth={2.5}/><Area type="monotone" dataKey="outflow" name="Outflow" stroke="#e5a04b" fill="#e5a04b" fillOpacity={0.06} strokeWidth={2.5}/></AreaChart></ResponsiveContainer></div></section>
        <section className="panel quick-panel"><div className="panel-head"><div><h2>Quick actions</h2><p>Common admin tasks</p></div></div><div className="quick-actions">
          <button onClick={()=>setActive("Customers")}><span className="quick-icon wine"><Users size={18}/></span><span><strong>Manage customers</strong><small>View and review accounts</small></span><ChevronDown className="quick-chevron" size={16}/></button>
          <button onClick={()=>setActive("Deposits")}><span className="quick-icon gold"><Wallet size={18}/></span><span><strong>Review deposits</strong><small>{pending} pending in sample data</small></span><ChevronDown className="quick-chevron" size={16}/></button>
          <button onClick={()=>setModal("limit")}><span className="quick-icon blue"><SlidersHorizontal size={18}/></span><span><strong>Transaction limits</strong><small>Set a limit preview</small></span><ChevronDown className="quick-chevron" size={16}/></button>
          <button onClick={()=>setActive("Activity Log")}><span className="quick-icon green"><Activity size={18}/></span><span><strong>Activity log</strong><small>Review administrative events</small></span><ChevronDown className="quick-chevron" size={16}/></button>
        </div></section>
      </div>
      <section className="panel table-panel"><div className="panel-head"><div><h2>Recent transactions</h2><p>Latest sample activity across the platform</p></div><button className="text-button" onClick={()=>setActive("Transactions")}>View all <ArrowUpRight size={15}/></button></div><div className="table-wrap"><table><thead><tr><th>Customer</th><th>Reference</th><th>Type</th><th>Date</th><th>Amount</th><th>Status</th></tr></thead><tbody>{transactions.slice(0,4).map(t=><tr key={t.id}><td><strong>{t.name}</strong></td><td className="mono">{t.id}</td><td>{t.kind}</td><td>{t.date}</td><td className={`amount ${t.amount<0?"negative":"positive"}`}>{t.amount<0?"−":"+"}{money(Math.abs(t.amount))}</td><td><Badge>{t.status}</Badge></td></tr>)}</tbody></table></div><div className="table-foot">Showing 4 of {transactions.length} sample transactions <span>Sample data only — Firebase not connected to records yet.</span></div></section>
    </>;
  };

  return <div className="app-shell">
    {mobileNav && <button className="mobile-scrim" aria-label="Close navigation" onClick={()=>setMobileNav(false)} />}
    <aside className={`sidebar ${mobileNav?"open":""}`}>
      <button className="brand" onClick={()=>{setActive("Overview");setMobileNav(false)}}><span className="brand-mark"><Wallet size={23}/></span><span><strong>Cash Flow</strong><small>ADMINISTRATION</small></span></button>
      <div className="workspace"><span className="workspace-dot"/> <span>Admin workspace</span><ChevronDown size={15}/></div>
      <nav>{navGroups.map(group=><div className="nav-group" key={group.title}><div className="nav-label">{group.title}</div>{group.items.map(item=><button key={item.id} className={`nav-item ${active===item.id?"active":""}`} onClick={()=>{setActive(item.id);setMobileNav(false)}}><item.icon size={18}/><span>{item.id}</span>{item.id==="Deposits"&&<em>{pending}</em>}</button>)}</div>)}</nav>
      <div className="sidebar-bottom"><div className="help-card"><span className="help-icon"><CircleHelp size={18}/></span><strong>Need help?</strong><p>Visit the admin setup guide.</p><button onClick={()=>notify("Help center will be added in a later step.")}>Open help center <ArrowUpRight size={13}/></button></div><div className="admin-profile"><span className="admin-avatar">AD</span><span><strong>Administrator</strong><small>Preview mode</small></span><button aria-label="Profile options" onClick={()=>notify("Secure admin sign-in will be added next.")}><MoreHorizontal size={19}/></button></div></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="top-left"><button className="mobile-menu icon-button" onClick={()=>setMobileNav(true)} aria-label="Open navigation"><Menu size={21}/></button><div className="breadcrumb"><span>Cash Flow</span><span>/</span><strong>{active}</strong></div></div><div className="top-actions"><div className="top-search"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search customers..." onFocus={()=>{if(active!=="Customers")setActive("Customers")}}/></div><button className="icon-button notification-button" aria-label="Notifications" onClick={()=>setNoticeOpen(v=>!v)}><Bell size={19}/><i/></button>{noticeOpen&&<div className="notification-popover"><strong>Notifications</strong><p>{pending} deposit requests need review in the sample data.</p><button className="text-button" onClick={()=>{setActive("Deposits");setNoticeOpen(false)}}>Review deposits <ArrowUpRight size={14}/></button></div>}<button className="top-admin" onClick={()=>notify("Admin sign-in will be secured with Firebase Auth.")}><span className="admin-avatar">AD</span><span><strong>Admin</strong><small>Owner</small></span><ChevronDown size={15}/></button></div></header>
      <div className="page-content"><div className="page-heading"><div><div className="eyebrow">CASH FLOW MANAGEMENT</div><h1>{title}</h1><p>{active==="Overview"?"Here’s what’s happening with your platform today.":"Manage and review your platform activity."}</p></div><div className="heading-actions"><span className="date-chip"><Clock3 size={15}/> Oct 12, 2026</span><button className="button" onClick={()=>{setActive("Customers");notify("Customer management opened.")}}><Plus size={16}/> Manage customers</button></div></div>
      <div className="demo-warning"><span><Eye size={17}/></span><div><strong>Design preview — sample data</strong><p>Actions here only change this page's temporary preview. No real accounts, balances, or transactions are changed. Firebase integration comes next.</p></div></div>
      {content()}
      <footer className="footer"><span>© 2026 Cash Flow. Admin workspace.</span><span><i/> Preview mode <span className="footer-sep">·</span> Secure integration pending</span></footer></div>
    </main>
    {selectedUser&&<div className="modal-backdrop" onClick={()=>setSelectedUser(null)}><section className="modal user-modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><span className="eyebrow">CUSTOMER DETAILS</span><h2>{selectedUser.name}</h2></div><button className="icon-button" onClick={()=>setSelectedUser(null)}><X size={19}/></button></div><div className="user-summary"><span className="avatar large">{selectedUser.name.split(" ").map(s=>s[0]).join("")}</span><div><strong>{selectedUser.email}</strong><small>Account {selectedUser.id}</small><Badge>{selectedUser.status}</Badge></div></div><div className="detail-grid"><div><small>Preview balance</small><strong>{money(selectedUser.balance)}</strong></div><div><small>Account type</small><strong>{selectedUser.type}</strong></div><div><small>Created</small><strong>{selectedUser.date}</strong></div><div><small>Account number</small><strong className="mono">{selectedUser.id}</strong></div></div><div className="modal-actions"><button className="button secondary" onClick={()=>setModal("credit")}><Plus size={15}/> Credit preview</button>{selectedUser.status==="Frozen"?<button className="button" onClick={()=>updateStatus(selectedUser.id,"Active")}><Check size={15}/> Unfreeze demo</button>:<button className="button danger" onClick={()=>updateStatus(selectedUser.id,"Frozen")}><Snowflake size={15}/> Freeze demo</button>}<button className="button secondary" onClick={()=>updateStatus(selectedUser.id,"Banned")}><Ban size={15}/> Ban demo</button></div><p className="modal-note">Preview only. Real admin operations will require authenticated server-side authorization and an audit log.</p></section></div>}
    {modal&&<div className="modal-backdrop" onClick={()=>setModal("")}><section className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><div><span className="eyebrow">ADMIN ACTION · PREVIEW</span><h2>{modal==="credit"?"Credit account preview":"Transaction limit preview"}</h2></div><button className="icon-button" onClick={()=>setModal("")}><X size={19}/></button></div>{modal==="credit"?<form onSubmit={doCredit} className="modal-form"><p>This changes only the sample balance shown in this browser. It does not move real funds.</p><label>Amount (NGN)<input type="number" min="1" step="1" value={creditAmount} onChange={e=>setCreditAmount(e.target.value)} placeholder="e.g. 50000" required/></label><label>Reason / audit note<input value={creditReason} onChange={e=>setCreditReason(e.target.value)} placeholder="Reason for this adjustment" required/></label><button className="button" type="submit">Update preview balance</button></form>:<form onSubmit={e=>{e.preventDefault();setModal("");notify(`Demo only: limit preview set to ${money(Number(limitAmount)||0)}.`)}} className="modal-form"><p>Set a sample limit for the UI. A real limit must be enforced by trusted backend logic.</p><label>Per-transaction limit (NGN)<input type="number" min="1" value={limitAmount} onChange={e=>setLimitAmount(e.target.value)} required/></label><button className="button" type="submit">Save limit preview</button></form>}</section></div>}
    {toast&&<div className="toast"><Check size={17}/>{toast}</div>}
  </div>;
}