import React from "react";
import { createRoot } from "react-dom/client";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, User } from "firebase/auth";
import { collection, getDocs, limit, query, where } from "firebase/firestore";
import {
  Activity, ArrowDownLeft, ArrowUpRight, Bell, ChevronDown, CircleHelp,
  CreditCard, DollarSign, Download, Eye, EyeOff, FileText, Filter,
  LayoutDashboard, LogOut, Menu, MoreHorizontal, Search, Settings, ShieldCheck,
  Snowflake, TrendingUp, UserCheck, Users, Wallet, X, CheckCircle2, Clock3,
  AlertTriangle, Ban, CircleDollarSign, CalendarDays
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { auth, db } from "./firebase";
import "./styles.css";

type NavItem = { label: string; icon: React.ElementType; section: string };
const navItems: NavItem[] = [
  { label: "Overview", icon: LayoutDashboard, section: "MAIN MENU" },
  { label: "Customers", icon: Users, section: "MAIN MENU" },
  { label: "Transactions", icon: Activity, section: "MAIN MENU" },
  { label: "Deposits", icon: ArrowDownLeft, section: "MAIN MENU" },
  { label: "Cards & Loans", icon: CreditCard, section: "SERVICES" },
  { label: "Reports", icon: FileText, section: "SERVICES" },
  { label: "Admin Settings", icon: Settings, section: "SYSTEM" },
];
const flowData = [
  { month: "Jan", inflow: 36000, outflow: 21000 },
  { month: "Feb", inflow: 42000, outflow: 26000 },
  { month: "Mar", inflow: 39000, outflow: 23000 },
  { month: "Apr", inflow: 52000, outflow: 31000 },
  { month: "May", inflow: 47000, outflow: 29000 },
  { month: "Jun", inflow: 61000, outflow: 35000 },
  { month: "Jul", inflow: 56000, outflow: 33000 },
  { month: "Aug", inflow: 72000, outflow: 41000 },
  { month: "Sep", inflow: 66000, outflow: 38000 },
  { month: "Oct", inflow: 79000, outflow: 45000 },
  { month: "Nov", inflow: 74000, outflow: 43000 },
  { month: "Dec", inflow: 92000, outflow: 51000 },
];
const initialTransactions = [
  { id: "TX-90821", name: "Olivia Rhye", email: "olivia.r@example.com", type: "Deposit", date: "Oct 12, 2026", amount: 2450, status: "Completed", initials: "OR" },
  { id: "TX-90820", name: "Phoenix Baker", email: "phoenix.b@example.com", type: "Transfer", date: "Oct 12, 2026", amount: -840, status: "Pending", initials: "PB" },
  { id: "TX-90819", name: "Lana Steiner", email: "lana.s@example.com", type: "Withdrawal", date: "Oct 11, 2026", amount: -1250, status: "Completed", initials: "LS" },
  { id: "TX-90818", name: "Demi Wilkinson", email: "demi.w@example.com", type: "Deposit", date: "Oct 11, 2026", amount: 5600, status: "Completed", initials: "DW" },
  { id: "TX-90817", name: "Candice Wu", email: "candice.w@example.com", type: "Transfer", date: "Oct 10, 2026", amount: -320, status: "Review", initials: "CW" },
];
const usd = (value: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value);

function App() {
  const [user, setUser] = React.useState<User | null>(null);
  const [authReady, setAuthReady] = React.useState(false);
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [showPassword, setShowPassword] = React.useState(false);
  const [authError, setAuthError] = React.useState("");
  const [active, setActive] = React.useState("Overview");
  const [mobileNav, setMobileNav] = React.useState(false);
  const [search, setSearch] = React.useState("");
  const [period, setPeriod] = React.useState("This year");
  const [firestoreStatus, setFirestoreStatus] = React.useState("Checking connection…");
  const [customers, setCustomers] = React.useState<{id:string; name:string; email:string; status:string; accountNumber?:string}[]>([]);
  const [transactions, setTransactions] = React.useState(initialTransactions);
  const [notice, setNotice] = React.useState("");

  React.useEffect(() => onAuthStateChanged(auth, (nextUser) => {
    setUser(nextUser);
    setAuthReady(true);
  }), []);

  React.useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      try {
        // This query is only for displaying customer records. Firestore rules must restrict
        // access to the server-authorized admin. UI state is never used as an authorization check.
        const snapshot = await getDocs(query(collection(db, "users"), limit(50)));
        if (cancelled) return;
        setCustomers(snapshot.docs.map(d => {
          const data = d.data();
          return { id: d.id, name: String(data.fullName || data.name || "Customer"), email: String(data.email || ""), status: String(data.status || "Pending"), accountNumber: data.accountNumber ? String(data.accountNumber) : undefined };
        }));
        setFirestoreStatus("Connected");
      } catch {
        if (!cancelled) setFirestoreStatus("Restricted or not configured");
      }
    })();
    return () => { cancelled = true; };
  }, [user]);

  const doLogin = async (event: React.FormEvent) => {
    event.preventDefault();
    setAuthError("");
    try {
      await signInWithEmailAndPassword(auth, email.trim(), password);
    } catch {
      setAuthError("Sign-in failed. Check your email/password and confirm that your Firebase Authentication provider is enabled.");
    }
  };

  if (!authReady) return <div className="loading-screen"><div className="brand-mark">CF</div><p>Loading Cash Flow Admin…</p></div>;

  if (!user) return (
    <main className="login-shell">
      <div className="login-card">
        <div className="brand-lockup"><div className="brand-mark"><Wallet size={24}/></div><div><strong>Cash Flow</strong><span>ADMINISTRATION</span></div></div>
        <div className="login-intro"><div className="eyebrow">SECURE ADMIN ACCESS</div><h1>Welcome back</h1><p>Sign in with the administrator account authorized for this project.</p></div>
        <form onSubmit={doLogin} className="login-form">
          <label>Email address<input autoComplete="username" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@example.com" required /></label>
          <label>Password<div className="password-field"><input autoComplete="current-password" type={showPassword ? "text" : "password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter your password" required /><button type="button" className="icon-button" onClick={()=>setShowPassword(!showPassword)} aria-label="Toggle password visibility">{showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button></div></label>
          {authError && <div className="error-message" role="alert">{authError}</div>}
          <button className="primary-button full-width" type="submit">Sign in securely <ArrowUpRight size={17}/></button>
        </form>
        <div className="login-security"><ShieldCheck size={17}/><span>Protected by Firebase Authentication</span></div>
        <p className="login-footnote">Admin privileges must be assigned by a trusted project owner. Creating an account does not automatically grant admin access.</p>
      </div>
      <div className="login-side"><div className="login-side-content"><span className="side-tag">CASH FLOW • CONTROL CENTER</span><h2>Clarity for every transaction.</h2><p>Manage customer accounts, review activity, and monitor financial operations in one place.</p><div className="side-stat"><span>Designed for</span><strong>Secure operations</strong><span className="side-dot"/></div></div><div className="login-side-bottom">CASH FLOW BANKING · ADMIN CONSOLE</div></div>
    </main>
  );

  const visibleTransactions = transactions.filter(t => [t.name, t.email, t.id, t.type].some(v => v.toLowerCase().includes(search.toLowerCase())));
  const visibleCustomers = customers.filter(c => [c.name, c.email, c.id, c.accountNumber || ""].some(v => v.toLowerCase().includes(search.toLowerCase())));
  const initials = (user.displayName || user.email || "A").slice(0,1).toUpperCase();

  const signOutNow = async () => { await signOut(auth); setMobileNav(false); };
  const sectionTitle = active === "Overview" ? "Overview" : active;
  const grouped = ["MAIN MENU", "SERVICES", "SYSTEM"];
  return (
    <div className="app-shell">
      {mobileNav && <button className="mobile-scrim" onClick={()=>setMobileNav(false)} aria-label="Close menu"/>}
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <button className="sidebar-brand" onClick={()=>setActive("Overview")} aria-label="Go to dashboard"><div className="brand-mark"><Wallet size={23}/></div><div><strong>Cash Flow</strong><span>ADMIN PANEL</span></div></button>
        <div className="workspace-chip"><span className="workspace-avatar">C</span><span><strong>Cash Flow Banking</strong><small>Owner workspace</small></span><ChevronDown size={15}/></div>
        <nav className="side-nav">
          {grouped.map(section => <div className="nav-group" key={section}><div className="nav-caption">{section}</div>{navItems.filter(n=>n.section===section).map(item=>{const Icon=item.icon;return <button key={item.label} onClick={()=>{setActive(item.label);setMobileNav(false);setSearch("");}} className={`nav-link ${active===item.label?"active":""}`}><Icon size={18}/><span>{item.label}</span>{item.label==="Deposits"&&<span className="nav-count">3</span>}</button>})}</div>)}
        </nav>
        <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><CircleHelp size={18}/></div><strong>Need help?</strong><p>Visit support for help with the admin console.</p><button onClick={()=>setNotice("Support integration will be configured in a later step.")}>Get support <ArrowUpRight size={14}/></button></div><button className="nav-link" onClick={()=>setActive("Admin Settings")}><Settings size={18}/><span>Settings</span></button><button className="profile-mini" onClick={signOutNow}><span className="avatar">{initials}</span><span className="profile-text"><strong>{user.displayName || "Administrator"}</strong><small>{user.email}</small></span><LogOut size={16}/></button></div>
      </aside>
      <main className="main-panel">
        <header className="topbar"><button className="mobile-menu icon-button" onClick={()=>setMobileNav(true)} aria-label="Open navigation"><Menu size={21}/></button><div className="breadcrumbs"><span>Admin Panel</span><span className="crumb-slash">/</span><strong>{sectionTitle}</strong></div><div className="topbar-actions"><div className="system-status"><span className="status-pulse"/><span>{firestoreStatus}</span></div><button className="icon-button notification-button" onClick={()=>setNotice("You’re all caught up. Notifications will appear here when configured.")} aria-label="Notifications"><Bell size={19}/><i/></button><div className="top-avatar">{initials}</div></div></header>
        <div className="page-content">
          <div className="page-heading"><div><div className="eyebrow">MONDAY, OCTOBER 12, 2026</div><h1>{active === "Overview" ? "Good to see you, Admin" : active}</h1><p>{active==="Overview"?"Here’s what’s happening with your Cash Flow accounts today.":`Manage and review ${active.toLowerCase()} for Cash Flow.`}</p></div><div className="heading-actions"><button className="secondary-button" onClick={()=>setNotice("Export will be enabled after real data and export permissions are configured.")}><Download size={16}/> Export</button><button className="primary-button" onClick={()=>setActive("Customers")}><Users size={16}/> View customers</button></div></div>
          {notice && <div className="notice-banner"><span>{notice}</span><button onClick={()=>setNotice("")} aria-label="Dismiss"><X size={16}/></button></div>}
          <section className="metrics-grid">
            <Metric icon={<Users size={19}/>} label="Total customers" value={String(customers.length)} trend="Live Firestore count" tone="plum" />
            <Metric icon={<Wallet size={19}/>} label="Active accounts" value={String(customers.filter(c=>c.status.toLowerCase()==="active"||c.status.toLowerCase()==="approved").length)} trend="Based on account status" tone="green" />
            <Metric icon={<Clock3 size={19}/>} label="Pending deposits" value="—" trend="Connect deposit workflow" tone="amber" />
            <Metric icon={<Snowflake size={19}/>} label="Frozen accounts" value={String(customers.filter(c=>c.status.toLowerCase()==="frozen").length)} trend="Based on account status" tone="blue" />
          </section>
          <section className="chart-grid">
            <div className="panel chart-panel"><div className="panel-heading"><div><h2>Cash flow overview</h2><p>Inflow and outflow · illustrative sample data</p></div><select value={period} onChange={e=>setPeriod(e.target.value)} aria-label="Chart period"><option>This year</option><option>Last 30 days</option><option>Last 7 days</option></select></div><div className="chart-legend"><span><i className="legend-in"/> Inflow</span><span><i className="legend-out"/> Outflow</span><strong>{period}</strong></div><div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={flowData} margin={{top:10,right:10,left:0,bottom:0}}><defs><linearGradient id="inflowFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8b1838" stopOpacity={0.18}/><stop offset="95%" stopColor="#8b1838" stopOpacity={0}/></linearGradient><linearGradient id="outflowFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#d7a0ad" stopOpacity={0.22}/><stop offset="95%" stopColor="#d7a0ad" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#f0edf0" vertical={false}/><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{fill:"#98929a",fontSize:11}} dy={9}/><YAxis axisLine={false} tickLine={false} tick={{fill:"#98929a",fontSize:11}} tickFormatter={(v)=>`$${v/1000}k`} width={42}/><Tooltip formatter={(v)=>usd(Number(v))} contentStyle={{borderRadius:12,border:"1px solid #eee5e9",fontSize:12}}/><Area type="monotone" dataKey="inflow" name="Inflow" stroke="#851637" strokeWidth={2.5} fill="url(#inflowFill)"/><Area type="monotone" dataKey="outflow" name="Outflow" stroke="#d49aaa" strokeWidth={2} fill="url(#outflowFill)"/></AreaChart></ResponsiveContainer></div><div className="chart-foot"><span><TrendingUp size={15}/> Sample visualization only</span><span>Currency: USD</span></div></div>
            <div className="panel activity-panel"><div className="panel-heading"><div><h2>Account activity</h2><p>Latest status snapshot</p></div><button className="dots-button" onClick={()=>setNotice("Activity options will be added with the live data workflow.")}><MoreHorizontal size={20}/></button></div><div className="activity-total"><span>Customer records loaded</span><strong>{customers.length}</strong><small>Maximum 50 records shown in this starter</small></div><div className="activity-list"><ActivityLine icon={<UserCheck size={16}/>} title="Customer records" subtitle="Loaded from Firestore" value={String(customers.length)} tone="green"/><ActivityLine icon={<Clock3 size={16}/>} title="Pending review" subtitle="Needs workflow setup" value="—" tone="amber"/><ActivityLine icon={<Snowflake size={16}/>} title="Frozen accounts" subtitle="From customer status" value={String(customers.filter(c=>c.status.toLowerCase()==="frozen").length)} tone="blue"/></div><button className="text-button" onClick={()=>setActive("Customers")}>Manage customers <ArrowUpRight size={15}/></button></div>
          </section>
          <section className="panel table-panel"><div className="panel-heading table-heading"><div><h2>{active==="Customers"?"Customer accounts":"Recent transactions"}</h2><p>{active==="Customers"?"Customer profiles currently available to your admin account":"Sample rows until transaction data is connected"}</p></div><div className="table-tools"><div className="search-field"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={active==="Customers"?"Search customers…":"Search transactions…"} aria-label="Search table"/></div><button className="secondary-button filter-button" onClick={()=>setNotice("Filters will be added when live transaction fields are configured.")}><Filter size={15}/> Filter</button></div></div>
            {active==="Customers" ? <div className="table-scroll"><table><thead><tr><th>CUSTOMER</th><th>ACCOUNT ID</th><th>STATUS</th><th>EMAIL</th><th>ACTION</th></tr></thead><tbody>{visibleCustomers.map(c=><tr key={c.id}><td><div className="customer-cell"><span className="customer-avatar">{c.name.split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase()}</span><strong>{c.name}</strong></div></td><td>{c.accountNumber||c.id}</td><td><StatusPill status={c.status}/></td><td>{c.email||"—"}</td><td><button className="row-action" onClick={()=>setNotice("Customer actions will be enabled after secure server-side admin functions are deployed.")}>View <ArrowUpRight size={13}/></button></td></tr>)}{visibleCustomers.length===0&&<tr><td colSpan={5} className="empty-cell">{customers.length===0?"No customer records found. Create a test user and profile to see it here.":"No customers match your search."}</td></tr>}</tbody></table></div> : <div className="table-scroll"><table><thead><tr><th>TRANSACTION</th><th>TYPE</th><th>DATE</th><th>AMOUNT</th><th>STATUS</th><th></th></tr></thead><tbody>{visibleTransactions.map(t=><tr key={t.id}><td><div className="customer-cell"><span className="customer-avatar">{t.initials}</span><span className="transaction-name"><strong>{t.name}</strong><small>{t.id}</small></span></div></td><td><span className="type-cell">{t.type}</span></td><td>{t.date}</td><td className={`amount-cell ${t.amount>0?"positive":""}`}>{t.amount>0?"+":"−"}{usd(Math.abs(t.amount))}</td><td><StatusPill status={t.status}/></td><td><button className="dots-button" aria-label={`More options for ${t.id}`} onClick={()=>setNotice("Transaction actions will be connected to secure server-side functions.")}><MoreHorizontal size={18}/></button></td></tr>)}</tbody></table></div>}
            <div className="table-footer"><span>{active==="Customers"?`${visibleCustomers.length} customer records shown`:`${visibleTransactions.length} transaction rows shown`}</span><button className="text-button" onClick={()=>setActive(active==="Customers"?"Overview":"Transactions")}>{active==="Customers"?"Back to overview":"View transactions"} <ArrowUpRight size={14}/></button></div>
          </section>
          <footer className="app-footer"><span>© 2026 Cash Flow Banking</span><span><span className="footer-dot"/> Admin console starter · secure setup in progress</span><span>USD · English (US)</span></footer>
        </div>
      </main>
    </div>
  );
}

function Metric({icon,label,value,trend,tone}:{icon:React.ReactNode;label:string;value:string;trend:string;tone:string}) {
  return <div className="metric-card"><div className="metric-top"><span className={`metric-icon ${tone}`}>{icon}</span><button className="dots-button" aria-label={`${label} information`}><MoreHorizontal size={18}/></button></div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-trend"><span className="neutral-trend">{trend}</span></div></div>;
}
function ActivityLine({icon,title,subtitle,value,tone}:{icon:React.ReactNode;title:string;subtitle:string;value:string;tone:string}) {
  return <div className="activity-line"><span className={`activity-icon ${tone}`}>{icon}</span><span className="activity-copy"><strong>{title}</strong><small>{subtitle}</small></span><strong className="activity-value">{value}</strong></div>;
}
function StatusPill({status}:{status:string}) {
  const normalized=status.toLowerCase();
  const cls=normalized==="active"||normalized==="approved"||normalized==="completed"?"success":normalized==="pending"||normalized==="review"?"pending":normalized==="frozen"||normalized==="banned"||normalized==="declined"?"danger":"neutral";
  return <span className={`status-pill ${cls}`}><i/>{status}</span>;
}

createRoot(document.getElementById("root")!).render(<React.StrictMode><App/></React.StrictMode>);