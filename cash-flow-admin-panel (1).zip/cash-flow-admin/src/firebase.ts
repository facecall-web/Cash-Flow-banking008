import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCmEb3RK-lSdGlMQVVcjotkQ_orj1VnjAM",
  authDomain: "cash-flow-banking-c708d.firebaseapp.com",
  projectId: "cash-flow-banking-c708d",
  storageBucket: "cash-flow-banking-c708d.firebasestorage.app",
  messagingSenderId: "415852501810",
  appId: "1:415852501810:web:91f293b7a4aec98858552b"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);