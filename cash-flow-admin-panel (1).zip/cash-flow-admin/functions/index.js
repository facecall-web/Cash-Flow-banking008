const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { beforeUserCreated } = require("firebase-functions/v2/identity");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();

/**
 * Run this only from a trusted owner environment (never from the web app).
 * The callable endpoint can only be used by an existing administrator.
 * Initial owner bootstrap is intentionally an operator-only CLI step; see README.
 */
exports.getAdminOverview = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Administrator access required.");
  }
  const [usersSnap, txSnap, depositSnap] = await Promise.all([
    db.collection("users").limit(500).get(),
    db.collection("transactions").limit(500).get(),
    db.collection("depositRequests").where("status", "==", "pending").limit(200).get()
  ]);
  const users = usersSnap.docs.map(d => ({ id: d.id, ...d.data() }));
  return {
    customerCount: usersSnap.size,
    activeCount: users.filter(u => ["active", "approved"].includes(String(u.status || "").toLowerCase())).length,
    frozenCount: users.filter(u => String(u.status || "").toLowerCase() === "frozen").length,
    transactionCount: txSnap.size,
    pendingDeposits: depositSnap.size,
    generatedAt: new Date().toISOString()
  };
});

exports.setCustomerStatus = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Administrator access required.");
  }
  const { uid, status, reason } = request.data || {};
  const allowed = ["active", "frozen", "banned", "pending", "declined"];
  if (typeof uid !== "string" || !allowed.includes(status) || typeof reason !== "string" || reason.trim().length < 4) {
    throw new HttpsError("invalid-argument", "Provide a customer UID, valid status, and a reason.");
  }
  const userRef = db.collection("users").doc(uid);
  await db.runTransaction(async tx => {
    const snap = await tx.get(userRef);
    if (!snap.exists) throw new HttpsError("not-found", "Customer record not found.");
    tx.update(userRef, { status, updatedAt: FieldValue.serverTimestamp() });
    tx.set(db.collection("adminAuditLog").doc(), {
      action: "set_customer_status", targetUid: uid, status, reason: reason.trim(),
      actorUid: request.auth.uid, createdAt: FieldValue.serverTimestamp()
    });
  });
  if (status === "banned") {
    try { await getAuth().updateUser(uid, { disabled: true }); } catch (e) {
      // Firestore status and audit log are written first; operator can reconcile Auth state.
      console.error("Could not disable Firebase Auth user", uid, e.message);
    }
  } else if (status === "active") {
    try { await getAuth().updateUser(uid, { disabled: false }); } catch (e) {
      console.error("Could not re-enable Firebase Auth user", uid, e.message);
    }
  }
  return { ok: true };
});

/**
 * This function is intentionally restricted to an existing admin.
 * Balance changes must be paired with an immutable ledger record in production.
 * Do not call until your ledger schema and currency/amount policy have been reviewed.
 */
exports.recordAdminNote = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Administrator access required.");
  }
  const { targetUid, action, reason } = request.data || {};
  if (typeof targetUid !== "string" || typeof action !== "string" || typeof reason !== "string" || reason.trim().length < 4) {
    throw new HttpsError("invalid-argument", "Target, action, and reason are required.");
  }
  await db.collection("adminAuditLog").add({
    targetUid, action, reason: reason.trim(), actorUid: request.auth.uid,
    createdAt: FieldValue.serverTimestamp()
  });
  return { ok: true };
});