// Run locally from a trusted computer with Firebase Admin SDK credentials.
// Never expose a service-account key in the browser or commit it to source control.
// Usage: GOOGLE_APPLICATION_CREDENTIALS=/secure/path/service-account.json node scripts/set-admin.mjs admin@example.com
import { applicationDefault, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import process from "node:process";

const email = process.argv[2];
if (!email) {
  console.error("Usage: node scripts/set-admin.mjs admin@example.com");
  process.exit(1);
}
initializeApp({ credential: applicationDefault(), projectId: "cash-flow-banking-c708d" });
const auth = getAuth();
const user = await auth.getUserByEmail(email);
await auth.setCustomUserClaims(user.uid, { ...(user.customClaims || {}), admin: true });
console.log(`Admin claim assigned to ${email} (${user.uid}). Sign out and sign back in to refresh the ID token.`);
console.log("Protect your Google Cloud/Firebase admin credentials. Do not run this script in a browser.");
